# timber-starter-theme
The "_s" for Timber: a dead-simple theme that you can build from
